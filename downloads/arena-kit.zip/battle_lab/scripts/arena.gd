extends Node3D

@onready var player = $Player
@onready var enemy = $Enemy
@onready var status: Label = $HUD/Status
@onready var stamina_panel := get_node_or_null("HUD/Stamina")
var stamina_needed := 0.0
var denied_action := ""
var finished := false

func _ready() -> void:
	if has_node("HUD/Lobby"):
		$HUD/Lobby.pressed.connect(func(): get_tree().change_scene_to_file("res://battle_lab/scenes/lobby.tscn"))
		var config := ConfigFile.new()
		if config.load("user://battle_lab_settings.cfg") == OK and config.get_value("display", "large_hud", false):
			status.add_theme_font_size_override("font_size", 26)
			if stamina_panel:
				stamina_panel.get_node("Caption").add_theme_font_size_override("font_size", 20)
	if stamina_panel:
		stamina_panel.visible = player.has_signal("stamina_changed")
		if stamina_panel.visible:
			player.stamina_changed.connect(_update_stamina)
			player.stamina_spent.connect(func(): denied_action = "")
			player.roll_denied.connect(func(): _show_stamina_denial("Roll", player.roll_stamina_cost))
			player.attack_denied.connect(func(): _show_stamina_denial("Attack", player.attack_stamina_cost))
			_update_stamina(player.stamina)
	player.health_changed.connect(_on_health_changed)
	enemy.health_changed.connect(_on_health_changed)
	_on_health_changed(0)

func _show_stamina_denial(action: String, cost: float) -> void:
	denied_action = action
	stamina_needed = cost
	_update_stamina(player.stamina)

func _update_stamina(value: float) -> void:
	var caption: Label = stamina_panel.get_node("Caption")
	var bar: ProgressBar = stamina_panel.get_node("Bar")
	bar.value = value
	if value + 0.000001 >= stamina_needed:
		denied_action = ""
	caption.text = "STAMINA   %d / 100" % floori(value + 0.000001)
	if not denied_action.is_empty():
		caption.text += "   ·   %s: Need %s" % [denied_action, String.num(stamina_needed, 2)]

func _on_health_changed(_value: int) -> void:
	if finished:
		return
	status.text = "SCOUT   %d / 3     •     SENTINEL   %d / 3" % [player.health, enemy.health]
	if player.health == 0 or enemy.health == 0:
		finished = true
		var result := "VICTORY" if enemy.health == 0 else "DEFEAT"
		$HUD/Result.text = result + "\nRestart: R or pad Y"
		$HUD/Result.show()
		player.set_physics_process(false)
		enemy.set_physics_process(false)
		for shot in get_tree().get_nodes_in_group("battle_lab_projectiles"):
			shot.queue_free()

func _unhandled_input(event: InputEvent) -> void:
	if finished and event.is_action_pressed("battle_lab_restart"):
		get_tree().reload_current_scene()

func _enter_tree() -> void:
	var bindings := {"battle_lab_move_left": KEY_A, "battle_lab_move_right": KEY_D, "battle_lab_move_forward": KEY_W, "battle_lab_move_back": KEY_S, "battle_lab_fire": KEY_SPACE, "battle_lab_roll": KEY_SHIFT, "battle_lab_restart": KEY_R}
	for action in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.2)
			var key := InputEventKey.new()
			key.physical_keycode = bindings[action]
			InputMap.action_add_event(action, key)
			var pad: InputEvent
			match bindings[action]:
				KEY_A, KEY_D, KEY_W, KEY_S:
					var motion := InputEventJoypadMotion.new()
					motion.axis = JOY_AXIS_LEFT_X if bindings[action] in [KEY_A, KEY_D] else JOY_AXIS_LEFT_Y
					motion.axis_value = -1.0 if bindings[action] in [KEY_A, KEY_W] else 1.0
					pad = motion
				_:
					var button := InputEventJoypadButton.new()
					button.button_index = {KEY_SPACE: JOY_BUTTON_X, KEY_SHIFT: JOY_BUTTON_B, KEY_R: JOY_BUTTON_Y}[bindings[action]]
					pad = button
			pad.device = -1
			InputMap.action_add_event(action, pad)
