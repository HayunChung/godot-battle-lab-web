extends Node3D

@export_range(1.0, 7.0, 0.25) var bot_range := 4.0
const SPEED := 4.0
const PULSE_SPEED := 11.0
const SHOT_DELAY := 0.45
const SPAWNS := [Vector2(-4, 0), Vector2(4, 0)]

var mode := ""
var positions: Array[Vector2] = [SPAWNS[0], SPAWNS[1]]
var facing: Array[Vector2] = [Vector2.RIGHT, Vector2.LEFT]
var hp: Array[int] = [3, 3]
var cooldown: Array[float] = [0.0, 0.0]
var moving: Array[bool] = [false, false]
var shots: Array[Dictionary] = []
var result := ""
var snapshot_clock := 0.0

@onready var pilots := [$Pilot1, $Pilot2]
@onready var network = $Network
@onready var net_menu = $HUD/Net/Options
@onready var match_hud = $HUD/Match

func _enter_tree() -> void:
	var bindings := {
		"duel_p1_left": KEY_A, "duel_p1_right": KEY_D, "duel_p1_up": KEY_W,
		"duel_p1_down": KEY_S, "duel_p1_shoot": KEY_SPACE,
		"duel_p2_left": KEY_LEFT, "duel_p2_right": KEY_RIGHT, "duel_p2_up": KEY_UP,
		"duel_p2_down": KEY_DOWN, "duel_p2_shoot": KEY_ENTER
	}
	for action in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
			var key := InputEventKey.new()
			key.physical_keycode = bindings[action]
			InputMap.action_add_event(action, key)

func _ready() -> void:
	# Give the guest its own armor color without changing the shared imported mesh.
	for part: MeshInstance3D in $Pilot2/Model.find_children("*", "MeshInstance3D", true, false):
		for surface in part.mesh.get_surface_count():
			var material := part.mesh.surface_get_material(surface) as StandardMaterial3D
			if material and material.resource_name.begins_with("Glacier"):
				var armor := material.duplicate() as StandardMaterial3D
				armor.albedo_color = Color("#ff9954")
				part.set_surface_override_material(surface, armor)
	$HUD/Modes/Options/Bot.pressed.connect(func(): start_round("bot"))
	$HUD/Modes/Options/Local.pressed.connect(func(): start_round("local"))
	$HUD/Modes/Options/Network.pressed.connect(_show_network)
	$HUD/Modes/Options/Lobby.pressed.connect(func(): get_tree().change_scene_to_file("res://battle_lab/scenes/lobby.tscn"))
	net_menu.get_node("Host").pressed.connect(_host_game)
	net_menu.get_node("Join").pressed.connect(_join_game)
	net_menu.get_node("Back").pressed.connect(show_modes)
	match_hud.get_node("Modes").pressed.connect(show_modes)
	match_hud.get_node("Rematch").pressed.connect(func(): start_round(mode))
	network.match_started.connect(func(is_host: bool): start_round("host" if is_host else "client"))
	network.status_changed.connect(func(message: String): net_menu.get_node("Status").text = message)
	network.match_ended.connect(_network_ended)
	network.snapshot_received.connect(apply_snapshot)
	show_modes()

func show_modes() -> void:
	mode = ""
	network.leave_game()
	$HUD/Match.hide()
	$HUD/Net.hide()
	$HUD/Modes.show()
	$HUD/Modes/Options/Bot.grab_focus()
	_reset_arena()
	_draw_round()

func _show_network() -> void:
	$HUD/Modes.hide()
	$HUD/Net.show()
	net_menu.get_node("Host").disabled = false
	net_menu.get_node("Join").disabled = false
	net_menu.get_node("Address").editable = true
	net_menu.get_node("Status").text = "Enter the host IP (LAN, shared VPN or public IPv4)."
	net_menu.get_node("Host").grab_focus()

func _host_game() -> void:
	var error: Error = network.host_game()
	if error == OK:
		net_menu.get_node("Host").disabled = true
		net_menu.get_node("Join").disabled = true
		net_menu.get_node("Address").editable = false
	else:
		net_menu.get_node("Status").text = "Could not host: %s. Check whether UDP 7000 is already in use." % error_string(error)

func _join_game() -> void:
	var error: Error = network.join_game(net_menu.get_node("Address").text.strip_edges())
	if error == OK:
		net_menu.get_node("Host").disabled = true
		net_menu.get_node("Join").disabled = true
		net_menu.get_node("Address").editable = false

func _network_ended(message: String) -> void:
	show_modes()
	_show_network()
	net_menu.get_node("Status").text = message

func _reset_arena() -> void:
	positions.assign(SPAWNS)
	facing.assign([Vector2.RIGHT, Vector2.LEFT])
	hp.assign([3, 3])
	cooldown.assign([0.0, 0.0])
	moving.assign([false, false])
	shots.clear()
	result = ""
	snapshot_clock = 0.0

func start_round(kind: String) -> void:
	mode = kind
	_reset_arena()
	$HUD/Modes.hide()
	$HUD/Net.hide()
	match_hud.show()
	var names := {"bot": "Bot practice", "local": "Local PvP", "host": "Network PvP • Host (P1)", "client": "Network PvP • Guest (P2)"}
	match_hud.get_node("Title").text = names[kind]
	match_hud.get_node("Help").text = "WASD + Space    /    Arrows + Enter" if kind == "local" else "WASD to move   •   Space to fire"
	_draw_round()

func read_move(slot: int) -> Vector2:
	var prefix := "duel_p1_" if slot == 0 else "duel_p2_"
	return Input.get_vector(prefix + "left", prefix + "right", prefix + "up", prefix + "down")

func read_fire(slot: int) -> bool:
	var prefix := "duel_p1_" if slot == 0 else "duel_p2_"
	return Input.is_action_pressed(prefix + "shoot")

func _physics_process(delta: float) -> void:
	if mode == "":
		return
	var direction := read_move(0)
	var firing := read_fire(0)
	if mode == "client":
		network.send_input(direction, firing)
		return
	var opponent_move := Vector2.ZERO
	var opponent_fire := false
	match mode:
		"bot":
			var offset := positions[0] - positions[1]
			var in_range := offset.length() <= bot_range
			if not offset.is_zero_approx():
				facing[1] = offset.normalized()
			opponent_move = Vector2.ZERO if in_range else facing[1]
			opponent_fire = in_range
		"local":
			opponent_move = read_move(1)
			opponent_fire = read_fire(1)
		"host":
			opponent_move = network.remote_direction
			opponent_fire = network.remote_fire
	tick_pair(direction, firing, opponent_move, opponent_fire, delta)
	_draw_round()
	if mode == "host":
		snapshot_clock += delta
		if snapshot_clock >= 0.05:
			snapshot_clock = 0.0
			network.broadcast_state(snapshot())

func tick_pair(p1: Vector2, fire1: bool, p2: Vector2, fire2: bool, delta: float) -> void:
	if result != "":
		return
	_move_pilot(0, p1, delta)
	_move_pilot(1, p2, delta)
	_try_shot(0, fire1)
	_try_shot(1, fire2)
	for i in range(shots.size() - 1, -1, -1):
		var shot := shots[i]
		var owner_slot: int = shot.owner
		var target := 1 - owner_slot
		var previous: Vector2 = shot.point
		shot.point = previous + shot.dir * PULSE_SPEED * delta
		shot.life -= delta
		var nearest := Geometry2D.get_closest_point_to_segment(positions[target], previous, shot.point)
		if nearest.distance_to(positions[target]) <= 0.55:
			hp[target] -= 1
			hp[target] = maxi(0, hp[target])
			shots.remove_at(i)
		elif shot.life <= 0.0 or absf(shot.point.x) > 9.0 or absf(shot.point.y) > 7.0:
			shots.remove_at(i)
	if hp[0] == 0 or hp[1] == 0:
		result = "Draw" if hp[0] == hp[1] else ("P1 wins" if hp[1] == 0 else "P2 wins")
		shots.clear()
		moving.assign([false, false])

func _move_pilot(slot: int, direction: Vector2, delta: float) -> void:
	moving[slot] = not direction.is_zero_approx()
	if moving[slot]:
		facing[slot] = direction.normalized()
		var next := positions[slot] + direction.limit_length(1.0) * SPEED * delta
		positions[slot] = next.clamp(Vector2(-8, -6), Vector2(8, 6))
	cooldown[slot] = maxf(0.0, cooldown[slot] - delta)

func _try_shot(slot: int, firing: bool) -> void:
	if firing and cooldown[slot] <= 0.0:
		# Start inside the shooter's hit radius so a close opponent is still reachable.
		shots.append({"point": positions[slot] + facing[slot] * 0.35, "dir": facing[slot], "owner": slot, "life": 1.8})
		cooldown[slot] = SHOT_DELAY

func snapshot() -> Dictionary:
	return {"positions": positions.duplicate(), "facing": facing.duplicate(), "hp": hp.duplicate(),
		"moving": moving.duplicate(), "shots": shots.duplicate(true), "result": result}

func apply_snapshot(state: Dictionary) -> void:
	if mode != "client":
		return
	positions.assign(state.positions)
	facing.assign(state.facing)
	hp.assign(state.hp)
	moving.assign(state.moving)
	shots.assign(state.shots)
	result = state.result
	_draw_round()

func _draw_round() -> void:
	for slot in 2:
		var p: Node3D = pilots[slot]
		p.position = Vector3(positions[slot].x, 0.05, positions[slot].y)
		p.rotation.y = atan2(-facing[slot].x, -facing[slot].y)
		var anim: AnimationPlayer = p.get_node("Model/AnimationPlayer")
		var clip := &"walk" if moving[slot] else &"idle"
		if anim.current_animation != clip:
			anim.play(clip)
	while $Pulses.get_child_count() < shots.size():
		var pulse := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.17
		sphere.height = 0.34
		pulse.mesh = sphere
		$Pulses.add_child(pulse)
	for i in $Pulses.get_child_count():
		var pulse: MeshInstance3D = $Pulses.get_child(i)
		pulse.visible = i < shots.size()
		if pulse.visible:
			var point: Vector2 = shots[i].point
			pulse.position = Vector3(point.x, 0.75, point.y)
			pulse.material_override = pilots[shots[i].owner].get_node("Ring").mesh.material
	match_hud.get_node("Score").text = "P1    %s / 3       •       P2    %s / 3" % [hp[0], hp[1]]
	match_hud.get_node("Result").text = result + (" • Wait for host to restart" if mode == "client" and result != "" else "")
	match_hud.get_node("Rematch").visible = result != "" and mode != "client"
