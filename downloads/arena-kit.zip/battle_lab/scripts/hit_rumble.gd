extends Node

const Pad = preload("res://battle_lab/scripts/gamepad.gd")

@export_range(0.0, 1.0, 0.05) var strength := 0.55
@export_range(0.05, 1.0, 0.01, "suffix:s") var duration := 0.18

func play_hit(target: int, mode: String) -> void:
	var device := device_for_hit(target, mode, Input.get_connected_joypads())
	if enabled and device >= 0 and strength > 0.0:
		Input.start_joy_vibration(device, strength, strength, duration)

func device_for_hit(target: int, mode: String, devices: Array) -> int:
	if mode == "local":
		return Pad.device_for_slot(devices, target, true)
	var own_slot := 1 if mode == "client" else 0
	if mode in ["host", "client", "bot"] and target == own_slot:
		return Pad.device_for_slot(devices, 0, false)
	return -1

const SAVE_PATH := "user://battle_lab_vibration.cfg"
var enabled := true

@onready var default_strength := strength
@onready var default_duration := duration

func _ready() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) != OK:
		return
	var saved_enabled = config.get_value("vibration", "enabled", enabled)
	if saved_enabled is bool:
		enabled = saved_enabled
	strength = _read_number(config, "strength", strength, 0.0, 1.0)
	duration = _read_number(config, "duration", duration, 0.05, 1.0)

func _read_number(config: ConfigFile, key: String, fallback: float, low: float, high: float) -> float:
	var value = config.get_value("vibration", key, fallback)
	if (value is float or value is int) and is_finite(value):
		return clampf(value, low, high)
	return fallback

func save_preferences(on: bool, force: float, seconds: float) -> Error:
	var config := ConfigFile.new()
	config.set_value("vibration", "enabled", on)
	config.set_value("vibration", "strength", force)
	config.set_value("vibration", "duration", seconds)
	var error := config.save(SAVE_PATH)
	if error == OK:
		enabled = on
		strength = force
		duration = seconds
		if not enabled or strength == 0.0:
			for device in Input.get_connected_joypads():
				Input.stop_joy_vibration(device)
	return error

func _local_pad() -> int:
	return Pad.device_for_slot(Input.get_connected_joypads(), 0, false)

func preview_local(force: float, seconds: float) -> bool:
	var device := _local_pad()
	if device < 0:
		return false
	if force == 0.0:
		Input.stop_joy_vibration(device)
	else:
		Input.start_joy_vibration(device, force, force, seconds)
	return true
