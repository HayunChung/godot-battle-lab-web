extends Node

enum Phase { ROOM, READY, LOADING, LOADED, COUNTDOWN, LIVE, ROUND_RESULT, MATCH_RESULT, LOAD_ERROR }

@export_file("*.tscn") var arena_path := "res://battle_lab/scenes/duel.tscn"
@export_range(2, 60) var ready_seconds := 15
@export_range(1, 10) var countdown_seconds := 3
@export_range(1, 5) var wins_needed := 2
@onready var panel := $Overlay/Center
@onready var title: Label = $Overlay/Center/Card/Column/Title
@onready var detail: Label = $Overlay/Center/Card/Column/Detail
@onready var bar: ProgressBar = $Overlay/Center/Card/Column/Progress
@onready var first: Button = $Overlay/Center/Card/Column/First
@onready var second: Button = $Overlay/Center/Card/Column/Second
@onready var back: Button = $Overlay/Center/Card/Column/Back
@onready var score: Label = $Overlay/Score
var phase := Phase.ROOM
var accepted := [false, false]
var wins := [0, 0]
var history: Array[String] = []
var seconds_left := 0.0
var arena_scene: PackedScene
var duel

func _ready() -> void:
	first.pressed.connect(_first_pressed)
	second.pressed.connect(func(): _accept(1))
	back.pressed.connect(_back_pressed)
	_room()

func _card(heading: String, body: String, action: String, exit_text: String = "") -> void:
	panel.show()
	title.text = heading
	detail.text = body
	first.text = action
	first.visible = action != ""
	first.disabled = false
	second.hide()
	second.disabled = false
	back.text = exit_text
	back.visible = exit_text != ""
	bar.hide()
	if first.visible:
		first.grab_focus()

func _room(note: String = "") -> void:
	phase = Phase.ROOM
	if is_instance_valid(duel):
		remove_child(duel)
		duel.queue_free()
	duel = null
	arena_scene = null
	wins.assign([0, 0])
	history.clear()
	score.hide()
	_card("Local match room", note + "Two players · first to %d round wins" % wins_needed, "Request ready check", "Back to lobby")

func _ready_check() -> void:
	phase = Phase.READY
	accepted.assign([false, false])
	seconds_left = ready_seconds
	_card("Accept the match", "", "P1 · Accept", "Decline")
	second.text = "P2 · Accept"
	second.show()
	_ready_status()

func _ready_status() -> void:
	detail.text = "%d / 2 accepted   ·   %d s left" % [accepted.count(true), ceili(seconds_left)]

func _accept(slot: int) -> void:
	if phase != Phase.READY or accepted[slot]:
		return
	accepted[slot] = true
	if slot == 0:
		first.disabled = true
		second.grab_focus()
	else:
		second.disabled = true
		first.grab_focus()
	_ready_status()
	if accepted.all(func(value): return value):
		_begin_load()

func _begin_load() -> void:
	phase = Phase.LOADING
	_card("Loading arena", "Reading the duel scene and its resources…", "")
	bar.value = 0
	bar.show()
	var error := ResourceLoader.load_threaded_request(arena_path, "PackedScene")
	if error != OK:
		_load_error()

func _poll_load() -> void:
	var progress := []
	var status := ResourceLoader.load_threaded_get_status(arena_path, progress)
	match status:
		ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			if not progress.is_empty():
				bar.value = progress[0] * 100
		ResourceLoader.THREAD_LOAD_LOADED:
			arena_scene = ResourceLoader.load_threaded_get(arena_path) as PackedScene
			if arena_scene == null:
				_load_error()
				return
			phase = Phase.LOADED
			_card("Arena loaded", "P1: WASD + Space    /    P2: arrows + Enter", "Enter arena", "Return to room")
			bar.value = 100
			bar.show()
		_:
			_load_error()

func _load_error() -> void:
	phase = Phase.LOAD_ERROR
	_card("Arena unavailable", "Could not load " + arena_path, "Retry load", "Return to room")

func _start_round() -> void:
	if not is_instance_valid(duel):
		duel = arena_scene.instantiate()
		if not duel.has_method("start_round"):
			duel.free()
			duel = null
			_load_error()
			return
		add_child(duel)
	duel.start_round("local")
	duel.get_node("HUD").hide()
	duel.set_physics_process(false)
	phase = Phase.COUNTDOWN
	seconds_left = countdown_seconds
	_card("Round %d" % (history.size() + 1), "Starts in %d" % countdown_seconds, "")
	score.show()
	_update_score()

func _update_score() -> void:
	score.text = "Round %d     P1  %d HP     P2  %d HP     |     Rounds  %d – %d" % [history.size()+1, duel.hp[0], duel.hp[1], wins[0], wins[1]]

func _finish_round() -> void:
	if phase != Phase.LIVE or duel.result == "":
		return
	duel.set_physics_process(false)
	if duel.hp[0] != duel.hp[1]:
		var winner := 0 if duel.hp[0] > duel.hp[1] else 1
		wins[winner] += 1
	history.append("R%d   %s   (%d : %d HP)" % [history.size()+1, duel.result, duel.hp[0], duel.hp[1]])
	score.hide()
	var summary := "Round wins   %d – %d\n%s" % [wins[0], wins[1], "\n".join(history.slice(-5))]
	if wins.max() >= wins_needed:
		phase = Phase.MATCH_RESULT
		_card("Match winner · P%d" % (1 if wins[0] > wins[1] else 2), summary, "Play again", "Leave to lobby")
	else:
		phase = Phase.ROUND_RESULT
		_card("Round %d · %s" % [history.size(),duel.result], summary, "Next round", "Leave to lobby")

func _first_pressed() -> void:
	match phase:
		Phase.ROOM: _ready_check()
		Phase.READY: _accept(0)
		Phase.LOAD_ERROR: _begin_load()
		Phase.LOADED, Phase.ROUND_RESULT: _start_round()
		Phase.MATCH_RESULT:
			_room()
			_ready_check()

func _back_pressed() -> void:
	match phase:
		Phase.READY: _room("Ready check declined.\n")
		Phase.LOAD_ERROR, Phase.LOADED: _room()
		Phase.ROOM, Phase.ROUND_RESULT, Phase.MATCH_RESULT:
			get_tree().change_scene_to_file("res://battle_lab/scenes/lobby.tscn")

func _process(delta: float) -> void:
	match phase:
		Phase.READY:
			seconds_left = maxf(0, seconds_left - delta)
			_ready_status()
			if seconds_left == 0:
				_room("Ready check expired.\n")
		Phase.LOADING: _poll_load()
		Phase.COUNTDOWN:
			seconds_left = maxf(0, seconds_left - delta)
			detail.text = "Starts in %d" % ceili(seconds_left)
			if seconds_left == 0:
				panel.hide()
				phase = Phase.LIVE
				duel.set_physics_process(true)
		Phase.LIVE:
			_update_score()
			_finish_round()
