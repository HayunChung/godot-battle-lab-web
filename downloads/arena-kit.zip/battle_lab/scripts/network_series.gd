extends Node

@export_range(1, 5) var wins_needed := 2
@export_file("*.tscn") var arena_path := "res://battle_lab/scenes/network_arena.tscn"
@onready var net = get_parent()
@onready var duel = net.get_parent()
@onready var panel: Control = duel.get_node("HUD/Series")
@onready var ui := panel.get_node("Card/Column")
@onready var confirm: Button = ui.get_node("Confirm")
var phase := ""
var epoch := 0
var votes := [false, false]
var wins := [0, 0]
var round_number := 1
var outcome := ""
var seconds := 0
var deadline := 0
var loading := false
var stage: Node3D
var final_state := {}

func _ready() -> void:
	confirm.pressed.connect(_confirm)
	ui.get_node("Leave").pressed.connect(duel.show_modes)

func clear_room() -> void:
	phase = ""
	epoch = 0
	loading = false
	_drop_stage()
	panel.hide()

func _drop_stage() -> void:
	if is_instance_valid(stage):
		stage.get_parent().remove_child(stage)
		stage.queue_free()
	stage = null
	duel.get_node("Set").show()

func connected(is_host: bool) -> void:
	duel.get_node("HUD/Net").hide()
	ui.get_node("Role").text = "Network PvP · Host (P1)" if is_host else "Network PvP · Guest (P2)"
	if is_host:
		_new_match()

func _new_match() -> void:
	wins.assign([0, 0])
	round_number = 1
	outcome = ""
	final_state.clear()
	_transition("ready")

func is_live(packet_epoch: int) -> bool:
	return phase == "live" and packet_epoch == epoch

func _transition(next: String) -> void:
	epoch += 1
	phase = next
	votes.assign([false, false])
	seconds = 3 if phase == "countdown" else 15
	deadline = Time.get_ticks_msec() + seconds * 1000
	net.remote_direction = Vector2.ZERO
	net.remote_fire = false
	_enter_phase()
	_publish()

func _publish() -> void:
	_render()
	if net.hosting and net.guest_id:
		_sync.rpc_id(net.guest_id, epoch, phase, votes, wins, round_number, outcome, seconds, final_state)

@rpc("authority", "call_remote", "reliable")
func _sync(version: int, next: String, acknowledgements: Array, score: Array, number: int, result: String, clock: int, snapshot: Dictionary) -> void:
	if not net.active_peer or net.hosting or multiplayer.get_remote_sender_id() != 1 or version < epoch:
		return
	var changed := version != epoch
	epoch = version
	phase = next
	votes.assign(acknowledgements)
	wins.assign(score)
	round_number = number
	outcome = result
	seconds = clock
	final_state = snapshot
	if changed:
		_enter_phase()
	_render()

func _enter_phase() -> void:
	loading = false
	match phase:
		"ready", "retry":
			_drop_stage()
			duel.mode = ""
		"loading":
			_drop_stage()
			loading = true
			ui.get_node("Progress").value = 0
			if ResourceLoader.load_threaded_request(arena_path, "PackedScene") != OK:
				_load_failed.call_deferred(epoch)
		"countdown":
			duel.start_round("host" if net.hosting else "client")
		"round", "result":
			if not net.hosting:
				duel.apply_snapshot(final_state)
	duel.get_node("HUD/Match").visible = phase == "live"
	panel.visible = phase != "live"

func _process(_delta: float) -> void:
	if loading:
		_poll_load()
	if not net.hosting:
		return
	if phase in ["ready", "countdown"]:
		var remaining := maxi(0, ceili((deadline - Time.get_ticks_msec()) / 1000.0))
		if remaining != seconds:
			seconds = remaining
			if seconds > 0:
				_publish()
			elif phase == "countdown":
				_transition("live")
			else:
				outcome = "Ready check expired"
				_transition("retry")
	elif phase == "live" and duel.result != "":
		outcome = duel.result
		final_state = duel.snapshot()
		if duel.hp[0] != duel.hp[1]:
			var winner := 0 if duel.hp[0] > duel.hp[1] else 1
			wins[winner] += 1
		_transition("result" if wins.max() >= wins_needed else "round")

func _poll_load() -> void:
	var progress := []
	var status := ResourceLoader.load_threaded_get_status(arena_path, progress)
	if not progress.is_empty():
		ui.get_node("Progress").value = progress[0] * 100
	if status == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
		return
	loading = false
	if status == ResourceLoader.THREAD_LOAD_LOADED:
		var packed := ResourceLoader.load_threaded_get(arena_path) as PackedScene
		if packed:
			var instance := packed.instantiate()
			if instance is Node3D:
				stage = instance
				duel.add_child(stage)
				duel.get_node("Set").hide()
				ui.get_node("Progress").value = 100
				_render()
				return
			instance.free()
	_load_failed(epoch)

func _load_failed(version: int) -> void:
	if phase != "loading" or version != epoch:
		return
	loading = false
	if net.hosting:
		outcome = "Host could not load the arena"
		_transition("retry")
	else:
		_guest_failed.rpc_id(1, epoch)

@rpc("any_peer", "call_remote", "reliable")
func _guest_failed(version: int) -> void:
	if net.hosting and multiplayer.get_remote_sender_id() == net.guest_id and phase == "loading" and epoch == version:
		outcome = "Guest could not load the arena"
		_transition("retry")

func _confirm() -> void:
	if confirm.disabled:
		return
	if net.hosting:
		_vote(0, epoch)
	else:
		confirm.disabled = true
		_guest_vote.rpc_id(1, epoch)

@rpc("any_peer", "call_remote", "reliable")
func _guest_vote(version: int) -> void:
	if net.hosting and multiplayer.get_remote_sender_id() == net.guest_id:
		_vote(1, version)

func _vote(slot: int, version: int) -> void:
	if epoch != version or votes[slot] or phase not in ["ready", "loading", "round", "result", "retry"]:
		return
	votes[slot] = true
	if not votes[0] or not votes[1]:
		_publish()
		return
	match phase:
		"ready": _transition("loading")
		"loading": _transition("countdown")
		"round":
			round_number += 1
			_transition("countdown")
		"result", "retry": _new_match()

func _render() -> void:
	if phase == "live":
		duel.match_hud.get_node("Help").text = "Round %d   ·   Wins %d – %d   ·   WASD + Space or left stick + X" % [round_number, wins[0], wins[1]]
		return
	var action := ""
	var heading := ""
	var detail := ""
	match phase:
		"ready":
			heading = "Ready check"
			action = "Ready"
			detail = "Both players must accept · %d s left" % seconds
		"loading":
			heading = "Loading arena"
			action = "Enter arena"
			detail = "When your arena has loaded, confirm entry."
		"countdown":
			heading = "Round %d" % round_number
			detail = "Starts in %d" % seconds
		"round", "result":
			heading = "Round %d · %s" % [round_number, outcome]
			if phase == "result":
				var winner := 1 if wins[0] > wins[1] else 2
				heading = "Match winner · P%d" % winner
			detail = "Round wins   P1 %d – %d P2\nLast round · %s" % [wins[0], wins[1], outcome]
			action = "Rematch" if phase == "result" else "Next round"
		"retry":
			heading = outcome
			action = "Try again"
	if action != "":
		detail += "\nP1  %s     P2  %s" % ["✓" if votes[0] else "…", "✓" if votes[1] else "…"]
	ui.get_node("Title").text = heading
	ui.get_node("Detail").text = detail
	ui.get_node("Progress").visible = phase == "loading"
	confirm.visible = action != ""
	confirm.text = action
	confirm.disabled = votes[0 if net.hosting else 1] or (phase == "loading" and not is_instance_valid(stage))
