extends "res://battle_lab/stages/roll_player.gd"

const SHOT := preload("res://battle_lab/scenes/projectile.tscn")
var fire_delay := 0.0

func _physics_process(delta: float) -> void:
	super(delta)
	if rolled_this_tick:
		return
	fire_delay = maxf(0.0, fire_delay - delta)
	if Input.is_action_pressed("battle_lab_fire") and fire_delay <= 0.0 and pay_for_attack():
		var shot := SHOT.instantiate()
		get_parent().add_child(shot)
		shot.global_position = global_position + Vector3.UP * 0.65 + facing * 0.55
		shot.direction = facing
		fire_delay = 0.25
		stamina_wait = 1.0
