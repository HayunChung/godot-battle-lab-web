extends Control

const SAVE_PATH := "user://battle_lab_settings.cfg"
var config := ConfigFile.new()
@onready var toggle: CheckButton = $Center/VBox/LargeHUD

func _ready() -> void:
	config.load(SAVE_PATH)
	toggle.button_pressed = config.get_value("display", "large_hud", false)
	_update_preview(toggle.button_pressed)
	toggle.toggled.connect(_save_size)
	$Center/VBox/Back.pressed.connect(func(): get_tree().change_scene_to_file("res://battle_lab/scenes/lobby.tscn"))
	toggle.grab_focus()

func _save_size(enabled: bool) -> void:
	config.set_value("display", "large_hud", enabled)
	var error := config.save(SAVE_PATH)
	_update_preview(enabled)
	$Center/VBox/Notice.text = "Saved on this device." if error == OK else "Could not save settings to disk."

func _update_preview(enabled: bool) -> void:
	$Center/VBox/Preview.add_theme_font_size_override("font_size", 26 if enabled else 16)
