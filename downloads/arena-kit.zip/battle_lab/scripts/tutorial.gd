extends Node3D

const HINTS := ["Move with W, A, S or D.", "Press Space to fire a pulse.", "Press Shift to roll.", "Training complete. Enter the arena when ready."]
var step := 0
@onready var player = $Player
@onready var previous_position: Vector3 = player.position
var walked := 0.0

func _ready() -> void:
	$HUD/Actions/Start.pressed.connect(func(): get_tree().change_scene_to_file("res://battle_lab/scenes/arena.tscn"))
	$HUD/Actions/Back.pressed.connect(func(): get_tree().change_scene_to_file("res://battle_lab/scenes/lobby.tscn"))
	child_entered_tree.connect(_on_child_entered)
	_show_step()

func _on_child_entered(child: Node) -> void:
	if step == 1 and child.is_in_group("battle_lab_projectiles"):
		_advance()

func _physics_process(_delta: float) -> void:
	match step:
		0:
			var travel := Vector2(player.position.x - previous_position.x, player.position.z - previous_position.z)
			previous_position = player.position
			if not player.rolled_this_tick:
				walked += travel.length()
			if walked > 0.25:
				_advance()
		2:
			if player.rolling:
				_advance()

func _advance() -> void:
	step += 1
	_show_step()

func _show_step() -> void:
	$HUD/Prompt.text = "TRAINING   %d / 3\n%s" % [mini(step + 1, 3), HINTS[step]]
	$HUD/Actions/Start.disabled = step < 3

func _enter_tree() -> void:
	var bindings := {"battle_lab_move_left": KEY_A, "battle_lab_move_right": KEY_D, "battle_lab_move_forward": KEY_W, "battle_lab_move_back": KEY_S, "battle_lab_fire": KEY_SPACE, "battle_lab_roll": KEY_SHIFT, "battle_lab_restart": KEY_R}
	for action in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
			var key := InputEventKey.new()
			key.physical_keycode = bindings[action]
			InputMap.action_add_event(action, key)
