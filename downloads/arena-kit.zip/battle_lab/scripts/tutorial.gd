extends Node3D

const HINTS := ["Move with WASD or the left stick.", "Fire with Space or pad X.", "Roll with Shift or pad B.", "Training complete. Enter the arena when ready."]
var step := 0
@onready var player = $Player
@onready var previous_position: Vector3 = player.position
var walked := 0.0

func _ready() -> void:
	$HUD/Actions/Start.pressed.connect(func(): get_tree().change_scene_to_file("res://battle_lab/scenes/arena.tscn"))
	$HUD/Actions/Back.pressed.connect(func(): get_tree().change_scene_to_file("res://battle_lab/scenes/lobby.tscn"))
	child_entered_tree.connect(_on_child_entered)
	_show_step()

func _on_child_entered(child: Node) -> void:
	if step == 1 and child.is_in_group("battle_lab_projectiles"):
		_advance()

func _physics_process(_delta: float) -> void:
	match step:
		0:
			var travel := Vector2(player.position.x - previous_position.x, player.position.z - previous_position.z)
			previous_position = player.position
			if not player.rolled_this_tick:
				walked += travel.length()
			if walked > 0.25:
				_advance()
		2:
			if player.rolling:
				_advance()

func _advance() -> void:
	step += 1
	_show_step()

func _show_step() -> void:
	$HUD/Prompt.text = "TRAINING   %d / 3\n%s" % [mini(step + 1, 3), HINTS[step]]
	$HUD/Actions/Start.disabled = step < 3

func _enter_tree() -> void:
	var bindings := {"battle_lab_move_left": KEY_A, "battle_lab_move_right": KEY_D, "battle_lab_move_forward": KEY_W, "battle_lab_move_back": KEY_S, "battle_lab_fire": KEY_SPACE, "battle_lab_roll": KEY_SHIFT, "battle_lab_restart": KEY_R}
	for action in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.2)
			var key := InputEventKey.new()
			key.physical_keycode = bindings[action]
			InputMap.action_add_event(action, key)
			var pad: InputEvent
			match bindings[action]:
				KEY_A, KEY_D, KEY_W, KEY_S:
					var motion := InputEventJoypadMotion.new()
					motion.axis = JOY_AXIS_LEFT_X if bindings[action] in [KEY_A, KEY_D] else JOY_AXIS_LEFT_Y
					motion.axis_value = -1.0 if bindings[action] in [KEY_A, KEY_W] else 1.0
					pad = motion
				_:
					var button := InputEventJoypadButton.new()
					button.button_index = {KEY_SPACE: JOY_BUTTON_X, KEY_SHIFT: JOY_BUTTON_B, KEY_R: JOY_BUTTON_Y}[bindings[action]]
					pad = button
			pad.device = -1
			InputMap.action_add_event(action, pad)
