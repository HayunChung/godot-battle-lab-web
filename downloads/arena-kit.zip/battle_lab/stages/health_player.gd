extends "res://battle_lab/stages/animated_player.gd"

signal health_changed(value: int)
@export var health: int = 3

func take_damage(amount: int) -> void:
	if amount <= 0 or health <= 0 or get_parent().get("finished") == true:
		return
	health = maxi(0, health - amount)
	health_changed.emit(health)
