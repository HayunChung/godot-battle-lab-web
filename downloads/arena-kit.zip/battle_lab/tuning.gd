extends RefCounted

const MOVE_SPEED: float = 4.0
const ATTACK_POWER: int = 1
