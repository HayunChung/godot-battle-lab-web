# Relay Arena

Open Godot **4.4.1 Stable**, choose **Import**, select this folder’s `project.godot`, and open the project. Wait for the initial asset import to finish, then press **F6** in an open scene to run that scene, or **F5** anywhere to run the arena. Click the game window to focus it.

Move with **W A S D**. Tap **Shift** to roll 2.4 meters in your current or last movement direction. The middle of the roll protects you from a blade hit. Each roll costs 40 and each attack costs 15 from the same 100 stamina. Recovery starts one second after the last roll or attack ends, including interrupted actions, at 20 per second. Select Player to tune Roll Stamina Cost, Attack Stamina Cost, and Stamina Regen per Second. Hold **Space** to fire in the last movement direction. You begin facing the sentinel. Both characters have three health points. A projectile deals one point. When the sentinel comes within 1.6 meters it stops, locks its facing, and swings its blade. The blade deals one point at the middle of each one-second swing. Step sideways during the wind-up to dodge, or shoot the sentinel to interrupt it. Press **R** after either ending to begin another round.

## Files to explore

| Path | Contents |
| --- | --- |
| `scenes/arena.tscn` | Main level, floor collision, fixed camera, lighting, combatants, and HUD |
| `scenes/player.tscn` | Player body, imported model, locomotion blend, and hurtbox |
| `scenes/enemy.tscn` | Sentinel, fallback blade, contact area for the collision exercise, and hurtbox |
| `scenes/projectile.tscn`, `scenes/impact.tscn` | Pulse and impact visuals |
| `scenes/set.tscn` | Decorative arena geometry |
| `assets/scout.glb` | Editable model with shared materials and two transform-animation clips, idle and walk |
| `practice/` | Three standalone scenes and scripts. Open any practice scene, press F6, and check the Output panel. |
| `stages/` | The movement, animation, and health scripts built up during the course |
| `scripts/` | Final combat and arena scripts. The player inherits the earlier lesson stages. |

Open **Project → Project Settings → Input Map** to inspect the seven actions. The numbered collision layers are named under **Layer Names → 3D Physics**. Layer 1 is World, layer 2 is Player hurtbox, and layer 3 is Enemy hurtbox. The bodies stand on the floor through body collision. Projectiles detect Enemy/Hurtbox. The enemy samples its blade segment against the scout’s horizontal hurt radius once per swing.

To edit the character in Blender, choose **File → Import → glTF 2.0** and open `assets/scout.glb`. Every piece is an editable mesh, and the two animations use object transforms. Save an editable Blender copy before re-exporting. Godot can open the supplied GLB directly.

The project and practice asset were created for Godot Battle Lab.

## Play a friend on two computers

1. Both players import the same copy of this project into Godot 4.4.1, open `scenes/duel.tscn` and press **F6**. In each game choose **Network PvP**.
2. On one PC choose **Host a match**. On the other, enter the host’s LAN IPv4 and choose **Join host**. For a two-window rehearsal on one PC, use `127.0.0.1`. For separate homes, follow the course’s internet lesson to reach the host over a shared VPN or UDP 7000 forwarding.
3. Accept on just one computer. Both players stay in the ready check until the second pilot accepts. After each computer loads, both click **Enter arena**. Try confirming on only one first. Combat begins after both confirmations and the countdown.
4. Both use **WASD** and **Space**. To reproduce a guest win, leave both pilots still at their spawn positions and fire only on the guest until three shots land. Compare the winner and 0–1 score. Both choose **Next round**. Repeat for a 0–2 final score.
5. Have one pilot choose **Rematch** and read the result screen on the other. Confirm on the other computer too. Go through ready and loading again and check that the new match starts with fresh HP and scores. Press **F8** on either computer to stop its game.

In Godot’s FileSystem, open `scripts/duel_network.gd` to trace the connection and input messages. Open `scripts/network_series.gd` to follow the flow from the two acceptances through loading, results and rematch.
