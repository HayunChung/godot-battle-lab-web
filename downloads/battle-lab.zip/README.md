# Relay Arena

Open Godot **4.4.1 Stable**, choose **Import**, select this folder’s `project.godot`, and open the project. Wait for the initial asset import to finish, then press **F6** in an open scene to run that scene, or **F5** anywhere to run the arena. Click the game window to focus it.

Move with **W A S D**. Tap **Shift** to roll 2.4 meters in your current or last movement direction. The middle of the roll protects you from a blade hit. Each roll costs 40 and each attack costs 15 from the same 100 stamina. Recovery starts one second after the last roll or attack ends, including interrupted actions, at 20 per second. Select Player to tune Roll Stamina Cost, Attack Stamina Cost, and Stamina Regen per Second. Hold **Space** to fire in the last movement direction. You begin facing the sentinel. Both characters have three health points. A projectile deals one point. When the sentinel comes within 1.6 meters it stops, locks its facing, and swings its blade. The blade deals one point at the middle of each one-second swing. Step sideways during the wind-up to dodge, or shoot the sentinel to interrupt it. Press **R** after either ending to begin another round.

## Files to explore

| Path | Contents |
| --- | --- |
| `scenes/arena.tscn` | Main level, floor collision, fixed camera, lighting, combatants, and HUD |
| `scenes/player.tscn` | Player body, imported model, locomotion blend, and hurtbox |
| `scenes/enemy.tscn` | Sentinel, fallback blade, contact area for the collision exercise, and hurtbox |
| `scenes/projectile.tscn`, `scenes/impact.tscn` | Pulse and impact visuals |
| `scenes/set.tscn` | Decorative arena geometry |
| `assets/scout.glb` | Editable model with shared materials and two transform-animation clips, idle and walk |
| `practice/` | Three standalone scenes and scripts. Open any practice scene, press F6, and check the Output panel. |
| `stages/` | The movement, animation, and health scripts built up during the course |
| `scripts/` | Final combat and arena scripts. The player inherits the earlier lesson stages. |

Open **Project → Project Settings → Input Map** to inspect the seven actions. The numbered collision layers are named under **Layer Names → 3D Physics**. Layer 1 is World, layer 2 is Player hurtbox, and layer 3 is Enemy hurtbox. The bodies stand on the floor through body collision. Projectiles detect Enemy/Hurtbox. The enemy samples its blade segment against the scout’s horizontal hurt radius once per swing.

To edit the character in Blender, choose **File → Import → glTF 2.0** and open `assets/scout.glb`. Every piece is an editable mesh, and the two animations use object transforms. Save an editable Blender copy before re-exporting. Godot can open the supplied GLB directly.

The project and practice asset were created for Godot Battle Lab.
