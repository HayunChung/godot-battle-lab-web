extends Node

@export var speed: float = 4.0

func _ready() -> void:
	print("Scout speed: ", speed)
