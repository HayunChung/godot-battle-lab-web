extends Node

signal fired(amount: int)

func _ready() -> void:
	fired.connect(_on_fired)
	shoot()

func shoot() -> void:
	fired.emit(1)

func _on_fired(amount: int) -> void:
	print("Shots fired: ", amount)
