extends Node

var health_values: Array[int] = [0, 2, 1]

func _ready() -> void:
	for hp in health_values:
		if hp > 0:
			print("Active target: ", hp)
		else:
			print("Disabled target: ", hp)
