extends Node3D

func play_hit() -> void:
	$Burst.show()
	$Burst.restart(true)
	$AnimationPlayer.stop()
	$AnimationPlayer.play(&"hit_flash")
	$AnimationPlayer.advance(0.0)

func clear_hit() -> void:
	$Burst.emitting = false
	$Burst.hide()
	$AnimationPlayer.stop()
	$Flash.hide()
	$Flash.scale = Vector3.ONE
