extends Node

signal hit_received(target: int)
signal match_started(is_host: bool)
signal match_ended(message: String)
signal status_changed(message: String)
signal snapshot_received(state: Dictionary)

const PORT := 7000
const HOST_ID := 1
const JOIN_TIMEOUT_MS := 8000
const INPUT_TIMEOUT_MS := 500

var remote_direction := Vector2.ZERO
var remote_fire := false
var guest_id := 0
var active_peer: ENetMultiplayerPeer
var hosting := false
var connecting := false
var join_started_ms := 0
var last_input_ms := 0

func _ready() -> void:
	# Keep this practice match separate from any networking in the host project.
	var duel_api := MultiplayerAPI.create_default_interface()
	get_tree().set_multiplayer(duel_api, get_path())
	multiplayer.peer_connected.connect(_peer_connected)
	multiplayer.peer_disconnected.connect(_peer_disconnected)
	multiplayer.connected_to_server.connect(_connected_to_host)
	multiplayer.connection_failed.connect(_connection_failed)
	multiplayer.server_disconnected.connect(_server_disconnected)

func host_game() -> Error:
	leave_game()
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_server(PORT, 1)
	if error != OK:
		status_changed.emit("Could not host on UDP %d. Close any other host on this computer and try again." % PORT)
		return error
	active_peer = peer
	hosting = true
	multiplayer.multiplayer_peer = peer
	status_changed.emit("Hosting on UDP %d. Waiting for one guest." % PORT)
	return OK

func join_game(address: String) -> Error:
	var host_address := address.strip_edges()
	if not host_address.is_valid_ip_address():
		status_changed.emit("Enter a numeric host IP without a port or URL.")
		return ERR_INVALID_PARAMETER
	leave_game()
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_client(host_address, PORT)
	if error != OK:
		status_changed.emit("Could not open the connection. Check the host address.")
		return error
	active_peer = peer
	connecting = true
	join_started_ms = Time.get_ticks_msec()
	multiplayer.multiplayer_peer = peer
	status_changed.emit("Connecting to %s on UDP %d…" % [host_address, PORT])
	return OK

func _peer_connected(id: int) -> void:
	if hosting and guest_id == 0:
		guest_id = id
		match_started.emit(true)

func _connected_to_host() -> void:
	if not connecting:
		return
	connecting = false
	match_started.emit(false)

func _peer_disconnected(id: int) -> void:
	if hosting and id == guest_id:
		_end_session.call_deferred(active_peer, "Guest left. Host again to play another match.")

func _connection_failed() -> void:
	_end_session.call_deferred(active_peer, "Join failed. Check host IP, VPN or UDP 7000 forwarding.")

func _server_disconnected() -> void:
	_end_session.call_deferred(active_peer, "Host left. Return to the match menu and join a new host.")

func _process(_delta: float) -> void:
	if connecting and Time.get_ticks_msec() - join_started_ms > JOIN_TIMEOUT_MS:
		_end_session(active_peer, "No host answered. Check host IP, VPN or UDP 7000 forwarding.")
	if hosting and Time.get_ticks_msec() - last_input_ms > INPUT_TIMEOUT_MS:
		remote_direction = Vector2.ZERO
		remote_fire = false

func send_input(direction: Vector2, fire: bool) -> void:
	if active_peer and not hosting and not connecting and active_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
		_receive_input.rpc_id(HOST_ID, direction, fire, $Series.epoch)

@rpc("any_peer", "call_remote", "unreliable_ordered", 1)
func _receive_input(direction: Vector2, fire: bool, epoch: int) -> void:
	if not hosting or multiplayer.get_remote_sender_id() != guest_id:
		return
	if not direction.is_finite() or not $Series.is_live(epoch):
		return
	remote_direction = direction.limit_length(1.0)
	remote_fire = fire
	last_input_ms = Time.get_ticks_msec()

func broadcast_state(state: Dictionary) -> void:
	if hosting and guest_id != 0 and active_peer.get_peer(guest_id) != null:
		_receive_state.rpc_id(guest_id, state, $Series.epoch)

@rpc("authority", "call_remote", "unreliable_ordered", 2)
func _receive_state(state: Dictionary, epoch: int) -> void:
	if active_peer and not hosting and multiplayer.get_remote_sender_id() == HOST_ID and $Series.is_live(epoch):
		snapshot_received.emit(state)

func _end_session(peer: ENetMultiplayerPeer, reason: String) -> void:
	if peer == null or peer != active_peer:
		return
	leave_game()
	match_ended.emit(reason)

func leave_game() -> void:
	hosting = false
	connecting = false
	guest_id = 0
	remote_direction = Vector2.ZERO
	remote_fire = false
	if active_peer:
		active_peer.close()
		multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
		active_peer = null

func _exit_tree() -> void:
	leave_game()
	get_tree().set_multiplayer(null, get_path())

func broadcast_hit(target: int) -> void:
	if hosting and guest_id != 0 and active_peer.get_peer(guest_id) != null:
		_receive_hit.rpc_id(guest_id, target, $Series.epoch)

@rpc("authority", "call_remote", "reliable")
func _receive_hit(target: int, epoch: int) -> void:
	if active_peer and not hosting and multiplayer.get_remote_sender_id() == HOST_ID and $Series.is_live(epoch):
		if target in [0, 1]:
			hit_received.emit(target)
