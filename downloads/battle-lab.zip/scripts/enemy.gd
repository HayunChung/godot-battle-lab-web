extends CharacterBody3D

signal health_changed(value: int)
@export var speed: float = 1.35
@export var health: int = 3
@export_range(0, 1, 0.01) var attack_contact_fraction: float = 0.5
const WEAPON_TIP := Vector3(0, 0.99, 0)
const ATTACK_RANGE := 1.6
const HURT_RADIUS := 0.37
const BLADE_RADIUS := 0.12

@onready var player: CharacterBody3D = $"../Player"
var clips: AnimationPlayer
@onready var blade: Node3D = $BladePivot
var weapon_skeleton: Skeleton3D
var weapon_bone := -1
var weapon_tip_bone := -1
var start_range := ATTACK_RANGE
var attacking := false
var attack_elapsed := 0.0
var attack_duration := 1.0
var contact_checked := false
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready() -> void:
	for animator: AnimationPlayer in $Model.find_children("*", "AnimationPlayer", true, false):
		clips = animator
		break
	if clips and clips.has_animation("attack"):
		var action := clips.get_animation("attack")
		action.loop_mode = Animation.LOOP_NONE
		attack_duration = maxf(action.length, 0.001)
		clips.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
		for skeleton: Skeleton3D in $Model.find_children("*", "Skeleton3D", true, false):
			var index := skeleton.find_bone("Weapon.R")
			if index >= 0:
				weapon_bone = index
				weapon_skeleton = skeleton
				weapon_tip_bone = skeleton.find_bone("WeaponTip")
				break

	if weapon_bone >= 0:
		clips.play("attack")
		clips.seek(attack_duration * attack_contact_fraction, true)
		var segment := _weapon_segment()
		var hilt: Vector3 = $Model.to_local(segment[0])
		var tip: Vector3 = $Model.to_local(segment[1])
		start_range = clampf(maxf(-hilt.z, -tip.z) + 0.25, 0.4, ATTACK_RANGE)
		clips.stop()

func _physics_process(delta: float) -> void:
	var offset := player.global_position - global_position
	offset.y = 0
	var direction := offset.normalized()
	if not attacking:
		if direction.length_squared() > 0:
			$Model.rotation.y = atan2(-direction.x, -direction.z)
		if offset.length() <= start_range:
			attacking = true
			attack_elapsed = 0
			contact_checked = false
			blade.rotation.y = $Model.rotation.y
			blade.visible = weapon_bone < 0
			if clips and clips.has_animation("attack"):
				clips.play("attack")
				clips.seek(0.0, true)
	velocity.x = 0.0 if attacking else direction.x * speed
	velocity.z = 0.0 if attacking else direction.z * speed
	if not is_on_floor():
		velocity.y -= gravity * delta
	move_and_slide()
	if attacking:
		_advance_attack(delta)

func _advance_attack(delta: float) -> void:
	attack_elapsed = minf(attack_elapsed + delta, attack_duration)
	var contact_time := attack_contact_fraction * attack_duration
	if not contact_checked and attack_elapsed + 0.000001 >= contact_time:
		contact_checked = true
		_sample_attack(contact_time)
		if _weapon_reaches_player():
			player.take_damage(1)
		if get_parent().get("finished") == true:
			return
	_sample_attack(attack_elapsed)
	if attack_elapsed >= attack_duration - 0.000001:
		cancel_attack()

func _sample_attack(time: float) -> void:
	if clips and clips.has_animation("attack"):
		clips.seek(time, true)
	var fraction := time / attack_duration
	var angle := 0.0
	if fraction < attack_contact_fraction:
		angle = lerpf(-1.2, 0, smoothstep(0, attack_contact_fraction, fraction))
	elif fraction > attack_contact_fraction:
		angle = lerpf(0, 0.9, smoothstep(attack_contact_fraction, 1, fraction))
	blade.get_node("Swing").rotation.y = angle

func _weapon_segment() -> PackedVector3Array:
	if weapon_bone < 0:
		return PackedVector3Array([blade.to_global(Vector3(0, 0.85, -0.35)), blade.to_global(Vector3(0, 0.85, -1.55))])
	var weapon := weapon_skeleton.global_transform * weapon_skeleton.get_bone_global_pose(weapon_bone)
	var tip := weapon * WEAPON_TIP
	if weapon_tip_bone >= 0:
		tip = weapon_skeleton.to_global(weapon_skeleton.get_bone_global_pose(weapon_tip_bone).origin)
	return PackedVector3Array([weapon.origin, tip])

func _weapon_reaches_player() -> bool:
	var segment := _weapon_segment()
	var hilt := segment[0]
	var tip := segment[1]
	var target := Vector2(player.global_position.x, player.global_position.z)
	var nearest := Geometry2D.get_closest_point_to_segment(target, Vector2(hilt.x, hilt.z), Vector2(tip.x, tip.z))
	return target.distance_to(nearest) <= HURT_RADIUS + BLADE_RADIUS

func cancel_attack() -> void:
	attacking = false
	blade.hide()
	if clips and clips.current_animation == &"attack":
		clips.stop()

func take_damage(amount: int) -> void:
	if amount <= 0 or health <= 0 or get_parent().get("finished") == true:
		return
	cancel_attack()
	health = maxi(0, health - amount)
	health_changed.emit(health)
