extends RefCounted

const DEADZONE := 0.2

static func device_for_slot(devices: Array, slot: int, shared_keyboard: bool) -> int:
	if shared_keyboard and devices.size() == 1:
		return devices[0] if slot == 1 else -1
	return devices[slot] if slot < devices.size() else -1

static func stick(device: int) -> Vector2:
	if device < 0:
		return Vector2.ZERO
	var axes := Vector2(Input.get_joy_axis(device, JOY_AXIS_LEFT_X), Input.get_joy_axis(device, JOY_AXIS_LEFT_Y))
	var strength := axes.length()
	if strength <= DEADZONE:
		return Vector2.ZERO
	return axes.normalized() * minf(1.0, (strength - DEADZONE) / (1.0 - DEADZONE))
