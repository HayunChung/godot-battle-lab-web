extends Control

func _process(_delta: float) -> void:
	var devices := Input.get_connected_joypads()
	if devices.is_empty():
		$Status.text = "No gamepad detected. Connect USB or pair in Bluetooth settings.\nLeave this scene running and press a button on the controller."
		return
	var rows := PackedStringArray()
	for device in devices:
		var axes := Vector2(Input.get_joy_axis(device, JOY_AXIS_LEFT_X), Input.get_joy_axis(device, JOY_AXIS_LEFT_Y))
		var pressed := PackedStringArray()
		for index in 4:
			if Input.is_joy_button_pressed(device, index):
				pressed.append(["A", "B", "X", "Y"][index])
		rows.append("%s  ·  Device %d\nLeft stick   X %.2f   Y %.2f\nFace buttons   %s" % [Input.get_joy_name(device), device, axes.x, axes.y, " / ".join(pressed) if not pressed.is_empty() else "released"])
	$Status.text = "\n\n".join(rows)
