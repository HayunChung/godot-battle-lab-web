extends Node2D

signal hit

@onready var target: Polygon2D = $Target
@onready var burst: CPUParticles2D = $Burst
@onready var animation: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
	hit.connect(_play_hit)
	$HUD/Hit.pressed.connect(func(): _resolve_shot(target.global_position))

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_resolve_shot(get_global_mouse_position())

func _resolve_shot(point: Vector2) -> void:
	if Geometry2D.is_point_in_polygon(to_local(point) - target.position, target.polygon):
		$HUD/Status.text = "Hit confirmed"
		hit.emit()
	else:
		$HUD/Status.text = "Miss"

func _play_hit() -> void:
	burst.restart()
	burst.emitting = true
	animation.stop()
	animation.play(&"hit_flash")
