extends Node

const Pad = preload("res://scripts/gamepad.gd")

@export_range(0.0, 1.0, 0.05) var strength := 0.55
@export_range(0.05, 1.0, 0.01, "suffix:s") var duration := 0.18

func play_hit(target: int, mode: String) -> void:
	var device := device_for_hit(target, mode, Input.get_connected_joypads())
	if device >= 0 and strength > 0.0:
		Input.start_joy_vibration(device, strength, strength, duration)

func device_for_hit(target: int, mode: String, devices: Array) -> int:
	if mode == "local":
		return Pad.device_for_slot(devices, target, true)
	var own_slot := 1 if mode == "client" else 0
	if mode in ["host", "client", "bot"] and target == own_slot:
		return Pad.device_for_slot(devices, 0, false)
	return -1
