extends MeshInstance3D

func _ready() -> void:
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3.ONE * 2.5, 0.12)
	tween.tween_property(self, "scale", Vector3.ONE * 0.01, 0.12)
	tween.tween_callback(queue_free)
