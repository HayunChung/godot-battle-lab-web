extends Control

@onready var start: Button = $Center/VBox/Start

func _ready() -> void:
	start.pressed.connect(_start_battle)
	$Center/VBox/Tutorial.pressed.connect(_show_tutorial)
	$Center/VBox/Settings.pressed.connect(_show_settings)
	start.grab_focus()

func _start_battle() -> void:
	get_tree().change_scene_to_file("res://scenes/arena.tscn")

func _show_tutorial() -> void:
	get_tree().change_scene_to_file("res://scenes/tutorial.tscn")

func _show_settings() -> void:
	get_tree().change_scene_to_file("res://scenes/settings.tscn")
