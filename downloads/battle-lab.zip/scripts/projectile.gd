extends Area3D

const IMPACT := preload("res://scenes/impact.tscn")
@export var speed: float = 11.0
var direction := Vector3.FORWARD
var life := 1.8
var spent := false

func _ready() -> void:
	area_entered.connect(_on_area_entered)

func _physics_process(delta: float) -> void:
	global_position += direction * speed * delta
	life -= delta
	if life <= 0.0:
		queue_free()

func _on_area_entered(area: Area3D) -> void:
	if spent:
		return
	spent = true
	var burst := IMPACT.instantiate()
	get_parent().add_child(burst)
	burst.global_position = global_position
	area.get_parent().take_damage(1)
	queue_free()
