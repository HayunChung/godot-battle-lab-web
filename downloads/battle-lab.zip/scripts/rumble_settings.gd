extends Control

@export var receiver_path: NodePath
@onready var receiver = get_node_or_null(receiver_path)
@onready var panel: Window = $Panel
@onready var enabled_box: CheckButton = %Enabled
@onready var strength_slider: HSlider = %Strength
@onready var duration_slider: HSlider = %Duration

func _ready() -> void:
	$Open.disabled = receiver == null
	$Open.pressed.connect(open_settings)
	panel.close_requested.connect(close_settings)
	%Cancel.pressed.connect(close_settings)
	%Save.pressed.connect(_save)
	%Test.pressed.connect(_test_vibration)
	%Defaults.pressed.connect(_restore_defaults)
	strength_slider.value_changed.connect(func(_value): _show_values())
	duration_slider.value_changed.connect(func(_value): _show_values())
	panel.window_input.connect(func(event):
		if event.is_action_pressed("ui_cancel"):
			panel.set_input_as_handled()
			close_settings())

func open_settings() -> void:
	enabled_box.button_pressed = receiver.enabled
	strength_slider.value = receiver.strength
	duration_slider.value = receiver.duration
	_show_values()
	%Notice.text = "Saved on this computer. Network play continues."
	panel.popup_centered()
	enabled_box.grab_focus()

func close_settings() -> void:
	panel.hide()
	$Open.release_focus()

func _show_values() -> void:
	%StrengthLabel.text = "Strength   %.2f" % strength_slider.value
	%DurationLabel.text = "Duration   %.2f s" % duration_slider.value

func _save() -> void:
	var error: Error = receiver.save_preferences(enabled_box.button_pressed, strength_slider.value, duration_slider.value)
	if error == OK:
		close_settings()
	else:
		%Notice.text = "Could not save on this computer. Try again."

func _test_vibration() -> void:
	if not receiver.preview_local(strength_slider.value, duration_slider.value):
		%Notice.text = "No local controller detected. Connect a pad and try again."
	elif strength_slider.value == 0.0:
		%Notice.text = "Strength is zero. Raise it to feel the test."
	else:
		%Notice.text = "Test sent to your local pad. Settings are still unsaved."

func _restore_defaults() -> void:
	enabled_box.button_pressed = true
	strength_slider.value = receiver.default_strength
	duration_slider.value = receiver.default_duration
	%Notice.text = "Project defaults selected. Choose Save to keep them."
