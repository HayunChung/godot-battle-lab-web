extends Node3D

const HINTS := ["Move with WASD or the left stick.", "Fire with Space or pad X.", "Roll with Shift or pad B.", "Training complete. Enter the arena when ready."]
var step := 0
@onready var player = $Player
@onready var previous_position: Vector3 = player.position
var walked := 0.0

func _ready() -> void:
	$HUD/Actions/Start.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/arena.tscn"))
	$HUD/Actions/Back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/lobby.tscn"))
	child_entered_tree.connect(_on_child_entered)
	_show_step()

func _on_child_entered(child: Node) -> void:
	if step == 1 and child.is_in_group("projectiles"):
		_advance()

func _physics_process(_delta: float) -> void:
	match step:
		0:
			var travel := Vector2(player.position.x - previous_position.x, player.position.z - previous_position.z)
			previous_position = player.position
			if not player.rolled_this_tick:
				walked += travel.length()
			if walked > 0.25:
				_advance()
		2:
			if player.rolling:
				_advance()

func _advance() -> void:
	step += 1
	_show_step()

func _show_step() -> void:
	$HUD/Prompt.text = "TRAINING   %d / 3\n%s" % [mini(step + 1, 3), HINTS[step]]
	$HUD/Actions/Start.disabled = step < 3
