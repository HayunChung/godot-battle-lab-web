extends "res://stages/motion.gd"

func _ready() -> void:
	var clips: AnimationPlayer = $Model/AnimationPlayer
	for clip in ["idle", "walk"]:
		clips.get_animation(clip).loop_mode = Animation.LOOP_LINEAR
	$AnimationTree.active = true

func _physics_process(delta: float) -> void:
	super(delta)
	var moving := Vector2(velocity.x, velocity.z).length() > 0.01
	$AnimationTree.set("parameters/blend_position", 1.0 if moving else 0.0)
