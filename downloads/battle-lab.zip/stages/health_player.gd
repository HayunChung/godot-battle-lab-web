extends "res://stages/animated_player.gd"

signal health_changed(value: int)
@export var health: int = 3

func take_damage(amount: int) -> void:
	if health <= 0:
		return
	health = maxi(0, health - amount)
	health_changed.emit(health)
