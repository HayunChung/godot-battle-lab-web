extends CharacterBody3D

@export var speed: float = 4.0
var facing := Vector3.FORWARD
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _physics_process(delta: float) -> void:
	var axes := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := Vector3(axes.x, 0, axes.y)
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	if direction.length_squared() > 0.0:
		facing = direction.normalized()
		$Model.rotation.y = atan2(-facing.x, -facing.z)
	_move_on_floor(delta)

func _move_on_floor(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	move_and_slide()
	global_position.x = clampf(global_position.x, -8.3, 8.3)
	global_position.z = clampf(global_position.z, -6.3, 6.3)
