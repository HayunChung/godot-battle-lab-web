extends "res://stages/health_player.gd"

signal stamina_changed(value: float)
signal stamina_spent
signal roll_denied
signal attack_denied
@export_range(0, 100, 0.01) var roll_stamina_cost: float = 40.0:
	set(value): roll_stamina_cost = clampf(value, 0, 100)
@export_range(0, 100, 0.01) var attack_stamina_cost: float = 15.0:
	set(value): attack_stamina_cost = clampf(value, 0, 100)
@export_range(0, 100, 0.01) var stamina_regen_per_second: float = 20.0:
	set(value): stamina_regen_per_second = clampf(value, 0, 100)
const MAX_STAMINA := 100.0
var stamina := MAX_STAMINA
var stamina_wait := 0.0

@export_range(0, 1, 0.001) var roll_safe_start: float = 4.0 / 18.0
@export_range(0, 1, 0.001) var roll_safe_end: float = 12.0 / 18.0
const ROLL_DISTANCE := 2.4
const ROLL_CLIP := &'roll'
var rolling := false
var rolled_this_tick := false
var roll_elapsed := 0.0
var roll_duration := 0.75
var roll_direction := Vector3.FORWARD
var roll_clips: AnimationPlayer
var authored_roll := false
var model_origin: Vector3
var model_pitch: float

func _ready() -> void:
	super()
	# Hit reactions pause movement. Recovery keeps its own physics clock.
	get_tree().physics_frame.connect(_recover_stamina)
	roll_clips = $AnimationTree.get_node($AnimationTree.anim_player)
	authored_roll = roll_clips.has_animation(ROLL_CLIP)
	if authored_roll:
		var clip := roll_clips.get_animation(ROLL_CLIP)
		clip.loop_mode = Animation.LOOP_NONE
		roll_duration = maxf(clip.length, 0.001)
		roll_clips.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL

func _physics_process(delta: float) -> void:
	var wants_roll: bool = not rolling and Input.is_action_just_pressed("roll") and get("attacking") != true
	if wants_roll:
		if _spend_stamina(roll_stamina_cost):
			_start_roll()
		else:
			roll_denied.emit()
	rolled_this_tick = rolling or wants_roll
	if not rolling:
		super(delta)
		return
	var next := minf(roll_elapsed + delta, roll_duration)
	var step_distance := ROLL_DISTANCE * (next - roll_elapsed) / roll_duration
	velocity.x = roll_direction.x * step_distance / delta
	velocity.z = roll_direction.z * step_distance / delta
	_move_on_floor(delta)
	roll_elapsed = next
	if authored_roll:
		roll_clips.seek(roll_elapsed, true)
	else:
		var pitch := -TAU * roll_elapsed / roll_duration
		$Model.rotation.x = model_pitch + pitch
		var pivot := Vector3.UP * 0.65
		$Model.position = model_origin + Basis(Vector3.UP, $Model.rotation.y) * (pivot - pivot.rotated(Vector3.RIGHT, pitch))
	if roll_elapsed >= roll_duration - 0.000001:
		_finish_roll()

func _spend_stamina(cost: float) -> bool:
	if stamina + 0.000001 < cost:
		return false
	stamina = maxf(0.0, stamina - cost)
	stamina_spent.emit()
	stamina_changed.emit(stamina)
	return true

func pay_for_attack() -> bool:
	if _spend_stamina(attack_stamina_cost):
		return true
	attack_denied.emit()
	return false

func _recover_stamina() -> void:
	if not is_inside_tree() or get_tree().paused or rolling or get("attacking") == true or health <= 0 or get_parent().get("finished") == true:
		return
	var delta := get_physics_process_delta_time()
	var waiting := minf(stamina_wait, delta)
	stamina_wait -= waiting
	var recovered := minf(MAX_STAMINA, stamina + (delta - waiting) * stamina_regen_per_second)
	if recovered != stamina:
		stamina = recovered
		stamina_changed.emit(stamina)

func _start_roll() -> void:
	var axes := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if axes.length_squared() > 0:
		facing = Vector3(axes.x, 0, axes.y).normalized()
	roll_direction = facing
	$Model.rotation.y = atan2(-facing.x, -facing.z)
	model_origin = $Model.position
	model_pitch = $Model.rotation.x
	roll_elapsed = 0
	rolling = true
	$AnimationTree.active = false
	if authored_roll:
		roll_clips.play(ROLL_CLIP)
		roll_clips.seek(0, true)

func _finish_roll() -> void:
	rolling = false
	stamina_wait = 1.0
	if authored_roll:
		roll_clips.stop()
	$Model.position = model_origin
	$Model.rotation.x = model_pitch
	$AnimationTree.active = true

func is_roll_protected() -> bool:
	var fraction := roll_elapsed / roll_duration
	return rolling and fraction + 0.0000001 >= roll_safe_start and fraction + 0.0000001 < roll_safe_end

func take_damage(amount: int) -> void:
	if amount <= 0 or health <= 0 or get_parent().get("finished") == true or is_roll_protected():
		return
	if rolling:
		_finish_roll()
	super(amount)
