extends VBoxContainer

@export_range(0.05, 0.5, 0.01) var guard_window := 0.18
signal guard_blocked
@export_range(0.2, 3, 0.05) var result_seconds := 1.5
var result_left := 0.0
const IMPACT := 1.0
var elapsed := 0.0
var pressed_at := -1.0
var running := false

func _ready() -> void:
	guard_blocked.connect($GuardSound.play)

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_R:
			elapsed = 0.0
			pressed_at = -1.0
			running = true
			$Meter.value = 0
			$Cue.text = "Wind-up"
		elif event.physical_keycode == KEY_G and running and pressed_at < 0:
			pressed_at = elapsed
			$Cue.text = "Guard raised"

func _physics_process(delta: float) -> void:
	if not running:
		if result_left > 0.0:
			result_left = maxf(0.0, result_left - delta)
			if result_left == 0.0:
				$Cue.text = "Press R when ready."
		return
	elapsed = minf(elapsed + delta, IMPACT)
	$Meter.value = elapsed / IMPACT
	if elapsed >= IMPACT:
		running = false
		result_left = result_seconds
		if pressed_at < 0:
			$Cue.text = "Hit • no guard"
		elif IMPACT - pressed_at <= guard_window:
			$Cue.text = "Perfect guard • damage blocked"
			guard_blocked.emit()
		else:
			$Cue.text = "Hit • guard expired"
