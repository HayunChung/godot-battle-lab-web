extends MeshInstance3D

@export_range(0.04, 0.5, 0.01) var expansion_seconds := 0.12

func _ready() -> void:
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3.ONE * 2.5, expansion_seconds)
	tween.tween_property(self, "scale", Vector3.ONE * 0.01, 0.12)
	tween.tween_callback(queue_free)
