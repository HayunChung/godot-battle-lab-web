extends "res://stages/motion.gd"

@export_range(1, 15, 0.1) var blend_rate := 6.0
var blend := 0.0

func _ready() -> void:
	var clips: AnimationPlayer = $Model/Hero/AnimationPlayer
	for clip in ["idle", "walk"]:
		clips.get_animation(clip).loop_mode = Animation.LOOP_LINEAR
	$AnimationTree.active = true

func _physics_process(delta: float) -> void:
	super(delta)
	var moving := Vector2(velocity.x, velocity.z).length() > 0.01
	blend = move_toward(blend, 1.0 if moving else 0.0, delta * blend_rate)
	$AnimationTree.set("parameters/blend_position", blend)
